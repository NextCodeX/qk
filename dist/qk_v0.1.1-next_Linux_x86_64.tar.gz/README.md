# Quick(qk)
It's golang util wrapper,  a script language like JavaScript.


## progress

### feature
1. text(string, file, regex) handler -- doing
2. date handler -- waiting
3. math handler -- waiting
4. excel handler -- waiting
5. xml handler -- waiting
6. db handler -- waiting
7. net handler -- waiting

### syntax and tool
1. chain call -- waiting
2. error handler -- waiting
